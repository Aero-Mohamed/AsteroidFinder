Planet_Radius = 6.371e6; % Meters
M = 5.972e24; % Kg
G = 6.67e-11; 
Mu = G*M;